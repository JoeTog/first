//
//  UITableView+RYChat.m
//  RYKit
//
//  Created by zhangll on 16/8/16.
//  Copyright © 2016年 安徽软云信息科技有限公司. All rights reserved.
//

#import "UITableView+RYChat.h"

@implementation UITableView (RYChat)

- (void)scrollToBottomWithAnimation:(BOOL)animation
{
    CGFloat offsetY = self.contentSize.height > self.height ? self.contentSize.height - self.height : -(HEIGHT_NAVBAR + HEIGHT_STATUSBAR);
//    CGFloat offsetY = self.contentSize.height > self.height ? self.contentSize.height - self.height : -(64);
    [self setContentOffset:CGPointMake(0, offsetY) animated:animation];
}

@end
