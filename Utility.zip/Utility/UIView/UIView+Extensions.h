//
//  UIView+Extensions.h
//  RYKit
//
//  Created by zhangll on 16/5/9.
//  Copyright © 2016年 安徽软云信息科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Extensions)

//注:类的分类扩展不能添加成员属性。@property如果在分类扩展里面，只会自动生成get,set方法的声明，不会生成成员属性，和方法的实现，需要自己申明实现
#pragma mark - 属性 property
/** 坐标(XY) */
@property CGPoint position;
/** 坐标(XY) */
@property CGPoint origin;
/** X */
@property CGFloat x;
/** Y */
@property CGFloat y;
/** 上 */
@property CGFloat top;
/** 左 */
@property CGFloat left;
/** 下 */
@property CGFloat bottom;
/** 右 */
@property CGFloat right;
/** 中心点X */
@property CGFloat centerX;
/** 中心点Y */
@property CGFloat centerY;
/** 大小 */
@property CGSize size;
/** 宽 */
@property CGFloat width;
/** 高 */
@property CGFloat height;
/** 可视 */
@property BOOL visible;

#pragma mark - 方法 method
/** 当前视图移除所有子视图 */
- (void)removeAllSubViews;
/** 初始化一个无大小的当前视图并添加到父视图上 */
- (id)initWithParent:(UIView *)parent;
/** 初始化一个无大小的当前视图并添加到父视图上(类方法) */
+ (id)viewWithParent:(UIView *)parent;

@end
