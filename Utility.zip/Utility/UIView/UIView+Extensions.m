//
//  UIView+Extensions.m
//  RYKit
//
//  Created by zhangll on 16/5/9.
//  Copyright © 2016年 安徽软云信息科技有限公司. All rights reserved.
//

#import "UIView+Extensions.h"

@implementation UIView (Extensions)

#pragma mark - 属性 property

//MARK:坐标(XY)
- (CGPoint)position {
    return self.frame.origin;
}
- (void)setPosition:(CGPoint)position {
    CGRect frame = self.frame;
    frame.origin = position;
    self.frame = frame;
}

//MARK:坐标(XY)
- (CGPoint)origin {
    return self.frame.origin;
}
- (void)setOrigin:(CGPoint)origin {
    CGRect frame = self.frame;
    frame.origin = origin;
    self.frame = frame;
}

//MARK:X
- (CGFloat)x {
    return self.frame.origin.x;
}
- (void)setX:(CGFloat)x {
    CGRect frame = self.frame;
    frame.origin.x = x;
    self.frame = frame;
}

//MARK:Y
- (CGFloat)y {
    return self.frame.origin.y;
}
- (void)setY:(CGFloat)y {
    CGRect frame = self.frame;
    frame.origin.y = y;
    self.frame = frame;
}

//MARK:上
- (CGFloat)top {
    return self.frame.origin.y;
}
- (void)setTop:(CGFloat)y {
    CGRect frame = self.frame;
    frame.origin.y = y;
    self.frame = frame;
}

//MARK:左
- (CGFloat)left {
    return self.frame.origin.x;
}
- (void)setLeft:(CGFloat)x {
    CGRect frame = self.frame;
    frame.origin.x = x;
    self.frame = frame;
}

//MARK:下
- (CGFloat)bottom {
    return self.frame.origin.y + self.frame.size.height;
}
- (void)setBottom:(CGFloat)bottom {
    CGRect frame = self.frame;
    frame.origin.y = bottom - self.frame.size.height;
    self.frame = frame;
}

//MARK:右
- (CGFloat)right {
    return self.frame.origin.x + self.frame.size.width;
}
- (void)setRight:(CGFloat)right {
    CGRect frame = self.frame;
    frame.origin.x = right - self.frame.size.width;
    self.frame = frame;
}

//MARK:中心点X
- (CGFloat)centerX {
    return self.center.x;
}
- (void)setCenterX:(CGFloat)centerX {
    self.center = CGPointMake(centerX, self.center.y);
}

//MARK:中心点Y
- (CGFloat)centerY {
    return self.center.y;
}
- (void)setCenterY:(CGFloat)centerY {
    self.center = CGPointMake(self.center.x, centerY);
}

//MARK:大小
- (CGSize)size {
    return self.frame.size;
}
- (void)setSize:(CGSize)size {
    CGRect frame = self.frame;
    frame.size = size;
    self.frame = frame;
}

//MARK:宽
- (CGFloat)width {
    return self.frame.size.width;
}
- (void)setWidth:(CGFloat)width {
    CGRect frame = self.frame;
    frame.size.width = width;
    self.frame = frame;
}

//MARK:高
- (CGFloat)height {
    return self.frame.size.height;
}
- (void)setHeight:(CGFloat)height {
    CGRect frame = self.frame;
    frame.size.height = height;
    self.frame = frame;
}

//MARK:可视
- (BOOL)visible {
    return !self.hidden;
}
- (void)setVisible:(BOOL)visible {
    self.hidden = !visible;
}

#pragma mark - 方法 method

//MARK:当前视图移除所有子视图
- (void)removeAllSubViews {
    for (id subview in self.subviews) {
        [subview removeFromSuperview];
    }
}

//MARK:初始化一个无大小的当前视图并添加到父视图上
- (id)initWithParent:(UIView *)parent {
    self = [self initWithFrame:CGRectZero];
    if (!self) return nil;
    [parent addSubview:self];
    
    return self;
}

//MARK:初始化一个无大小的当前视图并添加到父视图上(类方法)
+ (id)viewWithParent:(UIView *)parent {
    return [[self alloc] initWithParent:parent];
}

@end
