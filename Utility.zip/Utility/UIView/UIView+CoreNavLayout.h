//
//  UIView+CoreNavLayout.h
//  CoreNavVC
//
//  Created by 冯成林 on 16/1/14.
//  Copyright © 2016年 冯成林. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (CoreNavLayout)

-(void)layout_InSuperView_edgeinsetsZero;

@end
