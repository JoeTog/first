//
//  NSString+PinYin.h
//  RYKit
//
//  Created by zhangll on 15/9/8.
//  Copyright (c) 2015年 安徽软云信息科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (PinYin)

- (NSString *)pinyin;
- (NSString *)pinyinInitial;

@end
