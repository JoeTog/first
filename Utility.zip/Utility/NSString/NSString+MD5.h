//
//  NSString+MD5.h
//  RYKit
//
//  Created by zhangll on 16/4/11.
//  Copyright © 2016年 安徽软云信息科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (MD5)

+ (NSString *)getMd5_32BitWith:(NSString *)str;

@end
