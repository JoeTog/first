//
//  NSString+UIImage.m
//  ZhiBo
//
//  Created by RuanYun on 2017/5/16.
//  Copyright © 2017年 安徽软云信息科技有限公司. All rights reserved.
//

#import "NSString+UIImage.h"

@implementation NSString (UIImage)

+ (NSString *)fileWithOriginPath:(NSString *)originPath
{
    if ([originPath containsString:@"file/"]) {
        return [NSString stringWithFormat:@"%@%@", ServerDomain, originPath];
    }
    return originPath;
}

@end
