//
//  NSString+UIImage.h
//  ZhiBo
//
//  Created by RuanYun on 2017/5/16.
//  Copyright © 2017年 安徽软云信息科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (UIImage)

+ (NSString *)fileWithOriginPath:(NSString *)originPath;

@end
