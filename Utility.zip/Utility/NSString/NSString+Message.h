//
//  NSString+Message.h
//  RYKit
//
//  Created by zhangll on 16/8/23.
//  Copyright © 2016年 安徽软云信息科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Message)

- (NSAttributedString *)toMessageString;

@end
