//
//  BaseNavigationComtroller.h
//  通用框架
//
//  Created by muxi on 14-9-12.
//  Copyright (c) 2014年 muxi. All rights reserved.
//

#import <UIKit/UIKit.h>
///==========common==========
/** 基本设置 */
#import "UINavigationController+StatusBarStyle.h"
#import "UINavigationController+Appearance.h"
#import "UINavigationController+FDFullscreenPopGesture.h"
/** 返回设置 */
#import "UIViewController+Pop.h"
#import "UIBarButtonItem+Appearance.h"
/** 显隐导航栏 可滚导航栏 */
#import "UINavigationController+Plus.h"
#import "UIViewController+scrollNavbar.h"
///==========push-pop==========
#import "RotationAnimatedTransitioning.h"
#import "PinterestAnimatedTransitioning.h"
#import "ShapeLayerAnimatedTransitioning.h"
#import "FlipAnimatedTransitioning.h"
///==========subview==========
#import "ToolNetWorkView.h"
#import "ToolNetWorkSolveVC.h"
#import "TipView.h"

typedef enum {
    NavTypeNone = 0,
    NavTypePush,
    NavTypePop
} NavType;

@interface CoreNavVC : UINavigationController

@property (nonatomic, weak) UIView *navBgView;

#pragma mark - 不显示无网络提示框的视图数组集合
@property (nonatomic, strong) NSArray *hideNetworkBarControllerArray;       //此数组内的控制器（名）不会显示无网络提示框
@property (nonatomic, strong) NSArray *hideNetworkBarControllerArrayFull;   //不会显示无网络提示框的最终数组

#pragma mark - 首次安装后的教程页面
@property (nonatomic, assign) BOOL isShowedTipViewProperty;
@property (nonatomic, strong) TipView *tipView;

#pragma mark - 自定义push-pop动画
@property (nonatomic, assign) NavType navType;
@property (nonatomic, strong) RotationAnimatedTransitioning *at;
@property (nonatomic, strong) PinterestAnimatedTransitioning *pt;
@property (nonatomic, strong) ShapeLayerAnimatedTransitioning *st;
@property (nonatomic, strong) FlipAnimatedTransitioning *ft;

@end
