//
//  CoreNavVC+TipView.m
//  CoreNavVC
//
//  Created by 冯成林 on 15/12/23.
//  Copyright © 2015年 冯成林. All rights reserved.
//

#import "CoreNavVC+TipView.h"

@implementation CoreNavVC (TipView)

/** 处理tipView */
- (void)handleTipView
{
    KWS(weakSelf);
    
    self.tipView.ClickDismissBtnBlock = ^{
        [UIView animateWithDuration:0.5 animations:^{
            weakSelf.tipView.alpha = 0;
        } completion:^(BOOL finished) {
            [weakSelf.tipView removeFromSuperview];
            weakSelf.tipView = nil;
        }];
    };
}

/** 检查是否显示过了tipView */
- (void)checkShowedTipView
{
    if (!self.isShowedTipViewProperty) {
        //取出本地缓存的显示tipView的键值
        static NSString *const tipViewKey = @"TipViewKey";
        BOOL isShowed = [[NSUserDefaults standardUserDefaults] boolForKey:tipViewKey];
        //添加tipView
        [self.view addSubview:self.tipView];
        //添加tipView的约束
        self.tipView.translatesAutoresizingMaskIntoConstraints = NO;
        NSDictionary *views = @{@"tipView":self.tipView};
        NSArray *c_H = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[tipView]-0-|" options:0 metrics:nil views:views];
        NSArray *c_V = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|-0-[tipView]-0-|" options:0 metrics:nil views:views];
        [self.view addConstraints:c_H];
        [self.view addConstraints:c_V];
        //显示tipView的动画并本地缓存显示tipView的键值
        if (!isShowed) {
            [self.view endEditing:YES];
            [UIView animateWithDuration:0.8 animations:^{
                self.tipView.alpha = 1;
            }];
            //保存key
            [[NSUserDefaults standardUserDefaults] setBool:YES forKey:tipViewKey];
            self.isShowedTipViewProperty = YES;
        }
    }
}

@end
