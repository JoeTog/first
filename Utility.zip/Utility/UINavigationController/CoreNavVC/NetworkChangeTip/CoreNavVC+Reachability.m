//
//  CoreNavVC+Reachability.m
//  CoreNavVC
//
//  Created by 冯成林 on 15/12/23.
//  Copyright © 2015年 冯成林. All rights reserved.
//

#import "CoreNavVC+Reachability.h"
///==========common==========
#import "AppDelegate+NetStatus.h"
///==========subview==========
#import "ToolNetWorkView.h"
#import "ToolNetWorkSolveVC.h"

@implementation CoreNavVC (Reachability)

- (void)beginReachabilityNoti
{
    //判断系统的网络监听是否已打开
    if (!KAPPLEDATE.addNetStatus) {
        [KAPPLEDATE setNetStatusChangeObserver];//未打开则需要进行注册
    }
    //注册应用的网络状态监听
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(netWorkStatusChange) name:KNOTIFICATION_NETWORKCHANGE object:nil];
}

- (void)netWorkStatusChange
{
    if ([self needHideNetWorkBarWithVC:self.topViewController]) {
        //这里dismiss的原因在于可能由其他页面pop回来的时候，如果直接return会导致bar显示出来。
        [self dismissNetWorkBar];
        return;
    }
    
    if ([KAPPLEDATE isNETWORKEnable]) {
        [self dismissNetWorkBar];
    } else {
        [self showNetWorkBar];
    }
}

#pragma mark - 判断当前栈顶视图是否属于不显示网络状态提示条的视图数组
- (BOOL)needHideNetWorkBarWithVC:(UIViewController *)vc {
    NSString *vcStr = NSStringFromClass(vc.class);
    BOOL res = [self.hideNetworkBarControllerArrayFull containsObject:vcStr];
    return res;
}

#pragma mark - 显示网络状态提示条
- (void)showNetWorkBar {
    CGFloat y = self.navigationBar.frame.size.height + 20.0f;
    [ToolNetWorkView showNetWordNotiInViewController:self y:y];
}

#pragma mark - 隐藏网络状态提示条
- (void)dismissNetWorkBar {
    [ToolNetWorkView dismissNetWordNotiInViewController:self];
}

@end
