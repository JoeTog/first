//
//  UINavigationController+StatusBarStyle.m
//  RYKit
//
//  Created by zhangll on 16/4/11.
//  Copyright © 2016年 安徽软云信息科技有限公司. All rights reserved.
//

#import "UINavigationController+StatusBarStyle.h"

@implementation UINavigationController (StatusBarStyle)

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

@end
