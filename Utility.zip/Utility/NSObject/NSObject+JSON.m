//
//  NSObject+JSON.m
//  ZhiBo
//
//  Created by zhangll on 17/1/11.
//  Copyright © 2017年 安徽软云信息科技有限公司. All rights reserved.
//

#import "NSObject+JSON.h"

@implementation NSObject (JSON)

+ (instancetype)modelWithResponseJSON:(NSDictionary *)responseJSON {
    return [self mj_objectWithKeyValues:responseJSON];
}

@end
