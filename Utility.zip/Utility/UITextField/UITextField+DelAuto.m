//
//  UITextField+DelAuto.m
//  RYKit
//
//  Created by zhangll on 16/5/13.
//  Copyright © 2016年 安徽软云信息科技有限公司. All rights reserved.
//

#import "UITextField+DelAuto.h"

@implementation UITextField (DelAuto)

//屏蔽检查大小写，并设置描边样式输入框的光标偏移
- (UITextAutocapitalizationType)autocapitalizationType {
    return UITextAutocapitalizationTypeNone;
}

//屏蔽检查自动修正拼写
- (UITextAutocorrectionType)autocorrectionType {
    return UITextAutocorrectionTypeNo;
}

//在默认初始化阶段设置左边视图的间隙
- (UITextBorderStyle) borderStyle {
    if (!self.leftView && self.layer.borderWidth>0) {
        self.leftViewMode = UITextFieldViewModeAlways;
        self.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, AUTOLAYOUTWIDTH(30), AUTOLAYOUTHEIGHT(30))];
    }
    return UITextBorderStyleNone;
}

@end
