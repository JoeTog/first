//
//  UIColor+RYChat.m
//  RYKit
//
//  Created by zhangll on 16/8/18.
//  Copyright © 2016年 安徽软云信息科技有限公司. All rights reserved.
//

#import "UIColor+RYChat.h"

@implementation UIColor (RYChat)

#pragma mark - # 字体
+ (UIColor *)colorTextBlack {
    return [UIColor blackColor];
}

+ (UIColor *)colorTextGray {
    return [UIColor grayColor];
}

+ (UIColor *)colorTextGray1 {
    return KRGBA(160, 160, 160, 1.0);
}

#pragma mark - 灰色
+ (UIColor *)colorGrayBG {
    return KRGBA(245.0, 245.0, 245.0, 1.0);
}

+ (UIColor *)colorGrayCharcoalBG {
    return KRGBA(235.0, 235.0, 235.0, 1.0);
}

+ (UIColor *)colorGrayLine {
    return KRGBA(0, 0, 0, 1.0);
}

+ (UIColor *)colorGrayForChatBar {
    return KRGBA(245.0, 245.0, 247.0, 1.0);
}

+ (UIColor *)colorGrayForMoment {
    return KRGBA(243.0, 243.0, 245.0, 1.0);
}




#pragma mark - 绿色
+ (UIColor *)colorGreenDefault {
    return KRGBA(2.0, 187.0, 0.0, 1.0f);
}


#pragma mark - 蓝色
+ (UIColor *)colorBlueMoment {
    return KRGBA(74.0, 99.0, 141.0, 1.0);
}

#pragma mark - 黑色
+ (UIColor *)colorBlackForNavBar {
    return KRGBA(20.0, 20.0, 20.0, 1.0);
}

+ (UIColor *)colorBlackBG {
    return KRGBA(46.0, 49.0, 50.0, 1.0);
}

+ (UIColor *)colorBlackAlphaScannerBG {
    return [UIColor colorWithWhite:0 alpha:0.15];
}

+ (UIColor *)colorBlackForAddMenu {
    return KRGBA(71, 70, 73, 1.0);
}

+ (UIColor *)colorBlackForAddMenuHL {
    return KRGBA(65, 64, 67, 1.0);
}

@end
