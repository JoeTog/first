//
//  UIViewController+BlockSegue.m
//  RYKit
//
//  Created by zhangll on 16/4/20.
//  Copyright © 2016年 安徽软云信息科技有限公司. All rights reserved.
//

#import "UIViewController+BlockSegue.h"
#import <objc/runtime.h>

static const void *UIViewControllerDictionaryBlockKey = &UIViewControllerDictionaryBlockKey;

@implementation UIViewController (BlockSegue)

__attribute__((constructor))
void BlockSegue(void) {
    Class currentClass = [UIViewController class];
    
    SEL originalSel = @selector(prepareForSegue:sender:);
    SEL swizzledSel = @selector(jmg_prepareForSegue:sender:);
    
    Method originalMethod = class_getInstanceMethod(currentClass, originalSel);
    IMP swizzledImplementation = class_getMethodImplementation(currentClass, swizzledSel);
    
    method_setImplementation(originalMethod, swizzledImplementation);
}

- (void)jmg_prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if (segue.identifier == nil) {
        return;
    }
    
    if (!self.jmg_dictionaryBlock || !self.jmg_dictionaryBlock[segue.identifier]) {
        NSLog(@"Segue identifier '%@' doesn't exist", segue.identifier);
        return;
    }
    
    UIViewControllerSegueBlock segueBlock = self.jmg_dictionaryBlock[segue.identifier];
    segueBlock(sender, segue.destinationViewController, segue);
}

- (NSMutableDictionary *)jmg_dictionaryBlock {
    return objc_getAssociatedObject(self, UIViewControllerDictionaryBlockKey);
}

- (NSMutableDictionary *)jmg_createDictionaryBlock {
    if (!self.jmg_dictionaryBlock) {
        objc_setAssociatedObject(self, UIViewControllerDictionaryBlockKey, [NSMutableDictionary dictionary], OBJC_ASSOCIATION_RETAIN);
    }
    
    return self.jmg_dictionaryBlock;
}

#pragma mark - Public interface
- (void)configureSegue:(NSString *)identifier withBlock:(UIViewControllerSegueBlock)block {
    if (!identifier) {
        @throw [NSException exceptionWithName:NSInvalidArgumentException reason:@"Segue identifier can not be nil" userInfo:nil];
    }
    
    if (!block) {
        return ;
    }
    
    NSMutableDictionary *dBlocks = self.jmg_dictionaryBlock ?: [self jmg_createDictionaryBlock];
    [dBlocks setObject:block forKey:identifier];
}

- (void)performSegueWithIdentifier:(NSString *)identifier sender:(id)sender withBlock:(UIViewControllerSegueBlock)block {
    if (!identifier) {
        @throw [NSException exceptionWithName:NSInvalidArgumentException reason:@"Segue identifier can not be nil" userInfo:nil];
    }
    
    if (!block) {
#if DEBUG
        NSLog(@"performSegueWithIdentifier %@ withBlock not configured. Using default...", identifier);
#endif
        // Set a default configure block to allow segue to continue otherwise segue won't be performed...
        block = ^(id sender, id destinationVC, UIStoryboardSegue *segue) { /* Do nothing */ };
    }
    
    [self configureSegue:identifier withBlock:block];
    [self performSegueWithIdentifier:identifier sender:sender];
}

@end
